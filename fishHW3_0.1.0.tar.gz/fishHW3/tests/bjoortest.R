test_that("bjoor works" ,
          {
          expect_true(is.ggplot(bjoor(1,1,1,1, tempmin=1,tempmax=10)))
          })
