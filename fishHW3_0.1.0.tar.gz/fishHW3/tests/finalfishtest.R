test_that("finalfish works" ,
          {fish <- c("a", "b")
          price <- c(1, 1)
          fish1 <- data.frame(fish,price)

          locations = c("c", "d")
          #create table


          # generate a dataframe to store results
          catch= as.data.frame(matrix(nrow=length(fish), ncol=length(locations)))

          # for loop to populate
          for (i in 1:length(fish)) {
            for (j in 1:length(locations)) {
              catch[i,j]= 1
            }
          }

          fish <- c("a", "b")
          locations = c("c", "d")
          colnames(catch)=locations
          rownames(catch)= fish

          expect_that(finalfish(fish1,catch)$totalrevenue, equals(4))
                   })
