#' finalfish
#'
#' return revenue and catch summary for different locations
#' @param fish a table that has prices for different fish
#' @param catch a table that has the number caught for each fish species for each location
#' @param showplot  graph of revenue by location default FALSE
#' @return list with
#' \describe{
#' \item{most_frequent_fish}{most frequently caught fish in each location}
#' \item{revenue_location}{total revenue for each location}
#' \item{total_revenue}{total fisheries revenue (all locations)}
#' \item{plot}{graph of revenue by location}
#' }


finalfish = function(fish, catch, showplot=FALSE){

  result1 = rownames(catch[apply(catch, 2, which.max), ])
  result2 = temp <- catch
  temp$fishtype = rownames(temp)
  temp <- gather(temp, locations, key="location", value="fishcaught")
  temp$fishtype <- as.factor(temp$fishtype)

  colnames(fish)=c("fishtype", "price")

  temp <- inner_join(temp,fish,by="fishtype")
  temp$rev = temp$fishcaught*temp$price
  temp

  revsum <- temp %>%
    group_by(location) %>%
    summarise(revenue = sum(rev))

  result3 = revsum #not same order as above
  result4 = sum(revsum$revenue)

  tmp = as.data.frame(result3)
  colnames(tmp)=c("Revenue")
  tmp$locations = rownames(tmp)

  result5 =   if (showplot)
    p=ggplot(revsum,aes(x=location, y=revenue, fill=revenue))+geom_col()
  else
    p=NULL

  return(list(location=colnames(catch), mostfish=result1, locationrevenue=result3, totalrevenue=result4, plt=result5))
}
