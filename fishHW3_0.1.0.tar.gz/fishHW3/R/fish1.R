#' fish1
#'
#' Fish prices for different fish.  Provides type of fish and cost of each type of fish 
#' @format A table with 4 rows each indicating a different fish 2 columns with fish cost
#' \itemize{
#' \item cost of each fish
#' }
#' @source choosen by user
"fish1"
