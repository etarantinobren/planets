#' catch
#'
#' Catch data for different locations.  Provides location and amount of each type of fish caught at each location
#' @format A table with 4 rows each indicating a different fish and 5 columns of different locations
#' \itemize{
#' \item number of fish caught at each location
#' }
#' @source random
"catch"
