#' bjoor
#'
#' estimates fish growth rate as a function of temperature
#' @param a constant
#' @param b single-order coefficient b
#' @param c second-order coefficient c
#' @param d third-order coefficient d
#' @param tempmin minimum temperature default = 1
#' @param tempmax maximum temperature default = 25
#' @return
#' \describe{
#' \item{growth_rate_plot}{plot of growth rate as a function of temperature}
#' }


bjoor = function(a, b, c, d, tempmin=1, tempmax=25){

  growth <- as.data.frame(matrix(nrow=tempmax-tempmin+1, ncol=1))

  # for loop to populate
  for (i in tempmin:tempmax) {
    growth[i,]= a + b*i + c*i**2 + d*i**3
  }

  p <- ggplot(growth,aes(x=seq(tempmin,tempmax,by=1), y=V1)) +
    geom_line() +
    xlab("Temperature (C)") +
    ylab("Growth Rate")

  return(growthrate=p)
}
